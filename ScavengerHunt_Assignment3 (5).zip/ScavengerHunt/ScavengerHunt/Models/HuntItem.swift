import Foundation

// This model stores information about one scavenger hunt item.
struct HuntItem: Identifiable {
    let id = UUID()
    let name: String
    let clue: String
    var isFound: Bool = false
    var photoData: Data? = nil
}
