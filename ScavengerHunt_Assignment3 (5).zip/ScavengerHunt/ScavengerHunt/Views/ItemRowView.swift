import SwiftUI

struct ItemRowView: View {
    let item: HuntItem
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(item.name)
                    .font(.headline)
                
                Text(item.clue)
                    .font(.caption)
                    .foregroundStyle(.gray)
            }
            
            Spacer()
            
            if item.isFound {
                Text("Found")
                    .foregroundStyle(.green)
                    .bold()
            } else {
                Text("Not Found")
                    .foregroundStyle(.red)
            }
        }
        .padding(.vertical, 5)
    }
}
