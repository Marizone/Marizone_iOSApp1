import SwiftUI

struct HomeView: View {
    @ObservedObject var viewModel: HuntViewModel
    
    var body: some View {
        VStack(spacing: 25) {
            Text("Scavenger Hunt")
                .font(.largeTitle)
                .bold()
            
            Text("Welcome! Find hidden items, take photos, and earn a reward.")
                .multilineTextAlignment(.center)
                .padding()
            
            NavigationLink(destination: HuntListView(viewModel: viewModel)) {
                Text("Start Hunt")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundStyle(.white)
                    .cornerRadius(12)
            }
            
            NavigationLink(destination: ResultsView(viewModel: viewModel)) {
                Text("View Progress")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundStyle(.white)
                    .cornerRadius(12)
            }
            
            Spacer()
        }
        .padding()
    }
}
