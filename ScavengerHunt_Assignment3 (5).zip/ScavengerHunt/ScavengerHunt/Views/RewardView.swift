import SwiftUI

struct RewardView: View {
    let rewardText: String
    
    var body: some View {
        VStack(spacing: 10) {
            Text("Reward")
                .font(.headline)
            
            Text(rewardText)
                .font(.title3)
                .bold()
                .foregroundStyle(.green)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.green.opacity(0.15))
        .cornerRadius(12)
    }
}
