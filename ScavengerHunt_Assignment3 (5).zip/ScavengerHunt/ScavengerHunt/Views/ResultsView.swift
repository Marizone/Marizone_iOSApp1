import SwiftUI

struct ResultsView: View {
    @ObservedObject var viewModel: HuntViewModel
    
    @State private var showAlert = false
    @State private var submitMessage = ""
    
    var body: some View {
        VStack(spacing: 25) {
            Text("Progress")
                .font(.largeTitle)
                .bold()
            
            Text("Items Found: \(viewModel.foundCount) / 10")
                .font(.title2)
            
            RewardView(rewardText: viewModel.rewardMessage())
            
            Button {
                submitMessage = viewModel.submitResults()
                showAlert = true
            } label: {
                Text("Submit Results")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .foregroundStyle(.white)
                    .cornerRadius(12)
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle("Results")
        .alert("Submitted", isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(submitMessage)
        }
    }
}
