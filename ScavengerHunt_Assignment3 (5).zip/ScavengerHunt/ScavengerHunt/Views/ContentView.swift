import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = HuntViewModel()
    
    var body: some View {
        NavigationStack {
            HomeView(viewModel: viewModel)
        }
    }
}

#Preview {
    ContentView()
}
