import SwiftUI
import PhotosUI

struct ItemDetailView: View {
    @ObservedObject var viewModel: HuntViewModel
    let item: HuntItem
    
    @State private var selectedPhoto: PhotosPickerItem? = nil
    @State private var selectedPhotoData: Data? = nil
    
    var body: some View {
        let currentItem = viewModel.currentItem(for: item)
        
        VStack(spacing: 20) {
            Text(currentItem.name)
                .font(.largeTitle)
                .bold()
            
            Text("Clue:")
                .font(.headline)
            
            Text(currentItem.clue)
                .font(.title3)
                .multilineTextAlignment(.center)
                .padding()
            
            if let selectedPhotoData,
               let image = UIImage(data: selectedPhotoData) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 220)
                    .cornerRadius(12)
            } else if let savedPhotoData = currentItem.photoData,
                      let image = UIImage(data: savedPhotoData) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 220)
                    .cornerRadius(12)
            } else {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .frame(height: 220)
                    .overlay(
                        Text("No Photo Selected")
                            .foregroundStyle(.gray)
                    )
                    .cornerRadius(12)
            }
            
            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                Text("Choose Photo")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.orange)
                    .foregroundStyle(.white)
                    .cornerRadius(12)
            }
            
            Button {
                viewModel.markItemFound(item: currentItem, photoData: selectedPhotoData)
            } label: {
                Text(currentItem.isFound ? "Already Found" : "Mark as Found")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(currentItem.isFound ? Color.gray : Color.blue)
                    .foregroundStyle(.white)
                    .cornerRadius(12)
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle("Item Detail")
        .onChange(of: selectedPhoto) { newPhoto in
            Task {
                selectedPhotoData = try? await newPhoto?.loadTransferable(type: Data.self)
            }
        }
    }
}
