import SwiftUI

struct HuntListView: View {
    @ObservedObject var viewModel: HuntViewModel
    
    var body: some View {
        List {
            ForEach(viewModel.items) { item in
                NavigationLink(destination: ItemDetailView(viewModel: viewModel, item: item)) {
                    ItemRowView(item: item)
                }
            }
        }
        .navigationTitle("Hidden Items")
    }
}
