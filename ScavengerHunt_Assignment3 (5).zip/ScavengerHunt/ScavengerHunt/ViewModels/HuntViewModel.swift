import Foundation
import Combine

// This ViewModel controls the scavenger hunt app data and logic.
class HuntViewModel: ObservableObject {
    
    // The app starts with the 10 sample hunt items.
    @Published var items: [HuntItem] = sampleHuntItems
    
    // Counts how many items have been found.
    var foundCount: Int {
        items.filter { $0.isFound }.count
    }
    
    // Marks one item as found and saves its photo.
    func markItemFound(item: HuntItem, photoData: Data?) {
        if let index = items.firstIndex(where: { $0.id == item.id }) {
            items[index].isFound = true
            items[index].photoData = photoData
        }
    }
    
    // Finds the newest version of an item after it has been updated.
    func currentItem(for item: HuntItem) -> HuntItem {
        items.first(where: { $0.id == item.id }) ?? item
    }
    
    // Calculates the reward based on the number of found items.
    func rewardMessage() -> String {
        if foundCount == 10 {
            return "20% Discount + Grand Prize Entry"
        } else if foundCount >= 7 {
            return "20% Discount"
        } else if foundCount >= 5 {
            return "10% Discount"
        } else {
            return "No Reward Yet"
        }
    }
    
    // Simulates submitting results online.
    func submitResults() -> String {
        return "Your results were submitted successfully!"
    }
}
