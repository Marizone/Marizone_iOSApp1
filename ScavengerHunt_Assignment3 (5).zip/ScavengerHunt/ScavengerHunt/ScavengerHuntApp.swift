import SwiftUI

@main
struct ScavengerHuntApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
