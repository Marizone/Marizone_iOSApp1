import Foundation

// This file contains the 10 default scavenger hunt items.
let sampleHuntItems: [HuntItem] = [
    HuntItem(name: "Golden Key", clue: "Look near the main entrance or front desk."),
    HuntItem(name: "Red Coffee Cup", clue: "Find it close to a place where students buy drinks."),
    HuntItem(name: "Blue Notebook", clue: "Check around the study area or classroom desks."),
    HuntItem(name: "Green Plant", clue: "Look near a window or a quiet corner."),
    HuntItem(name: "Campus Poster", clue: "Search the walls in the hallway."),
    HuntItem(name: "Water Bottle", clue: "It may be near the student lounge or seating area."),
    HuntItem(name: "Laptop Sticker", clue: "Look around computers or laptop workstations."),
    HuntItem(name: "Library Card", clue: "A quiet study space may help you find this."),
    HuntItem(name: "Pencil Case", clue: "Check near classroom tables or chairs."),
    HuntItem(name: "Prize Box", clue: "This final item may be near the instructor or main office.")
]
