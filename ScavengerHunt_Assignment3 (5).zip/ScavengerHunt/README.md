# Scavenger Hunt App

This is an iOS SwiftUI app for Assignment 3.

## App Description

The app allows users to complete a scavenger hunt by finding 10 hidden items. Each item has a clue. When the user finds an item, they can choose a photo and mark the item as found.

## Features

- Home screen
- List of 10 scavenger hunt items
- Clues for each item
- Item detail screen
- Photo selection using PhotosUI
- Mark item as found
- Progress tracking
- Reward calculation
- Submit results button
- Beginner-friendly comments in the code

## Technologies Used

- Swift
- SwiftUI
- PhotosUI
- Xcode
- GitHub

## Reward Rules

- 5-6 items found: 10% Discount
- 7-9 items found: 20% Discount
- 10 items found: 20% Discount + Grand Prize Entry
- 0-4 items found: No Reward Yet

## Folder Structure

```text
ScavengerHunt
├── Models
│   └── HuntItem.swift
├── Data
│   └── SampleHuntData.swift
├── ViewModels
│   └── HuntViewModel.swift
├── Views
│   ├── ContentView.swift
│   ├── HomeView.swift
│   ├── HuntListView.swift
│   ├── ItemDetailView.swift
│   ├── ItemRowView.swift
│   ├── ResultsView.swift
│   └── RewardView.swift
└── Assets.xcassets
```
