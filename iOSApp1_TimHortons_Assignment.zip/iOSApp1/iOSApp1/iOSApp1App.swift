//
//  iOSApp1App.swift
//  iOSApp1
//
//  Created for MWD3A Assignment 1.
//  This file starts the SwiftUI app.
//

import SwiftUI

@main
struct iOSApp1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
