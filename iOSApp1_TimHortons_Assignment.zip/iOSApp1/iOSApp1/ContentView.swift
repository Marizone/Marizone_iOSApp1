//
//  ContentView.swift
//  iOSApp1
//
//  Main screen for the Tim Hortons Coffee Run app.
//  The app lets a team record orders, save them, and run a simple coffee timer.
//

import SwiftUI

struct ContentView: View {
    // These arrays keep the picker choices simple for a first assignment.
    let drinkOptions = ["Coffee", "Tea", "Iced Coffee", "French Vanilla", "Hot Chocolate", "Latte"]
    let sizeOptions = ["Small", "Medium", "Large", "Extra Large"]
    let milkOptions = ["Black", "Regular", "1 Milk", "2 Milk", "Cream", "2 Cream"]
    let sugarOptions = ["No Sugar", "1 Sugar", "2 Sugar", "Double Double", "Triple Triple"]

    // AppStorage saves the encoded orders even after the app closes.
    @AppStorage("savedOrders") private var savedOrdersData: Data = Data()

    // State values control what the user sees and enters on the screen.
    @State private var orders: [TeamOrder] = []
    @State private var personName = ""
    @State private var selectedDrink = "Coffee"
    @State private var selectedSize = "Medium"
    @State private var selectedMilk = "Regular"
    @State private var selectedSugar = "Double Double"
    @State private var notes = ""
    @State private var showingAddOrder = false
    @State private var showingTimer = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    if orders.isEmpty {
                        ContentUnavailableView(
                            "No Orders Yet",
                            systemImage: "cup.and.saucer",
                            description: Text("Tap Add Order to start today's coffee run.")
                        )
                    } else {
                        ForEach(orders) { order in
                            OrderRowView(order: order)
                        }
                        .onDelete(perform: deleteOrder)
                    }
                } header: {
                    Text("Today's Team Orders")
                }

                Section {
                    Button {
                        showingTimer = true
                    } label: {
                        Label("Start Coffee Run Timer", systemImage: "timer")
                    }
                } footer: {
                    Text("Use the timer while one teammate walks to Tim Hortons and comes back.")
                }
            }
            .navigationTitle("Tims Coffee Run")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add Order") {
                        showingAddOrder = true
                    }
                }
            }
            .onAppear(perform: loadOrders)
            .sheet(isPresented: $showingAddOrder) {
                addOrderView
            }
            .sheet(isPresented: $showingTimer) {
                CoffeeTimerView()
            }
        }
    }

    // This form is kept inside ContentView because it is short and easy to read.
    private var addOrderView: some View {
        NavigationStack {
            Form {
                Section("Team Member") {
                    TextField("Name", text: $personName)
                }

                Section("Drink") {
                    Picker("Drink", selection: $selectedDrink) {
                        ForEach(drinkOptions, id: \.self) { drink in
                            Text(drink)
                        }
                    }

                    Picker("Size", selection: $selectedSize) {
                        ForEach(sizeOptions, id: \.self) { size in
                            Text(size)
                        }
                    }
                }

                Section("How They Take It") {
                    Picker("Milk / Cream", selection: $selectedMilk) {
                        ForEach(milkOptions, id: \.self) { milk in
                            Text(milk)
                        }
                    }

                    Picker("Sugar", selection: $selectedSugar) {
                        ForEach(sugarOptions, id: \.self) { sugar in
                            Text(sugar)
                        }
                    }
                }

                Section("Extra Notes") {
                    TextField("Example: no lid, extra sleeve", text: $notes, axis: .vertical)
                        .lineLimit(3, reservesSpace: true)
                }
            }
            .navigationTitle("New Order")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        showingAddOrder = false
                        clearForm()
                    }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        addOrder()
                    }
                    .disabled(personName.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    // Adds a new order to the list and saves the updated list.
    private func addOrder() {
        let newOrder = TeamOrder(
            name: personName,
            drink: selectedDrink,
            size: selectedSize,
            milk: selectedMilk,
            sugar: selectedSugar,
            notes: notes,
            isFavourite: false
        )

        orders.append(newOrder)
        saveOrders()
        clearForm()
        showingAddOrder = false
    }

    // Removes orders when the user swipes left on a row.
    private func deleteOrder(at offsets: IndexSet) {
        orders.remove(atOffsets: offsets)
        saveOrders()
    }

    // Resets the form so the next order starts clean.
    private func clearForm() {
        personName = ""
        selectedDrink = "Coffee"
        selectedSize = "Medium"
        selectedMilk = "Regular"
        selectedSugar = "Double Double"
        notes = ""
    }

    // Saves the order array as JSON data in AppStorage.
    private func saveOrders() {
        if let encodedOrders = try? JSONEncoder().encode(orders) {
            savedOrdersData = encodedOrders
        }
    }

    // Loads saved orders when the app opens.
    private func loadOrders() {
        if let decodedOrders = try? JSONDecoder().decode([TeamOrder].self, from: savedOrdersData) {
            orders = decodedOrders
        }
    }
}

#Preview {
    ContentView()
}
