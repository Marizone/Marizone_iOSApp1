//
//  TeamOrder.swift
//  iOSApp1
//
//  This model stores one person's Tim Hortons order.
//  It uses Codable so the order can be saved with AppStorage.
//

import Foundation

struct TeamOrder: Identifiable, Codable {
    var id = UUID()
    var name: String
    var drink: String
    var size: String
    var milk: String
    var sugar: String
    var notes: String
    var isFavourite: Bool

    // A short sentence used in the list screen.
    var summary: String {
        "\(size) \(drink), \(milk), \(sugar)"
    }
}
