//
//  CoffeeTimerView.swift
//  iOSApp1
//
//  A simple timer inspired by the HIITFit timer idea.
//  It can be used to time a coffee run.
//

import SwiftUI

struct CoffeeTimerView: View {
    @Environment(\.dismiss) private var dismiss

    // The timer starts at 10 minutes, which is a reasonable coffee run guess.
    @State private var secondsRemaining = 600
    @State private var timerIsRunning = false

    // Timer publishes an event every second.
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        NavigationStack {
            VStack(spacing: 30) {
                Text("Coffee Run Timer")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text(timeText)
                    .font(.system(size: 64, weight: .bold, design: .rounded))
                    .monospacedDigit()
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 20))

                ProgressView(value: Double(600 - secondsRemaining), total: 600)
                    .padding(.horizontal)

                HStack(spacing: 20) {
                    Button(timerIsRunning ? "Pause" : "Start") {
                        timerIsRunning.toggle()
                    }
                    .buttonStyle(.borderedProminent)

                    Button("Reset") {
                        secondsRemaining = 600
                        timerIsRunning = false
                    }
                    .buttonStyle(.bordered)
                }

                Text("When the timer reaches 0, the coffee runner should be back soon.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                Spacer()
            }
            .padding()
            .navigationTitle("Timer")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .onReceive(timer) { _ in
                guard timerIsRunning else { return }

                if secondsRemaining > 0 {
                    secondsRemaining -= 1
                } else {
                    timerIsRunning = false
                }
            }
        }
    }

    // Converts seconds into a MM:SS display.
    private var timeText: String {
        let minutes = secondsRemaining / 60
        let seconds = secondsRemaining % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

#Preview {
    CoffeeTimerView()
}
