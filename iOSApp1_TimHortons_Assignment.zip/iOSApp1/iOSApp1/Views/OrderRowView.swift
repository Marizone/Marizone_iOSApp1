//
//  OrderRowView.swift
//  iOSApp1
//
//  Shows one coffee order in the main list.
//

import SwiftUI

struct OrderRowView: View {
    let order: TeamOrder

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "cup.and.saucer.fill")
                .font(.title2)
                .foregroundStyle(.brown)
                .frame(width: 32)

            VStack(alignment: .leading, spacing: 5) {
                Text(order.name)
                    .font(.headline)

                Text(order.summary)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                if !order.notes.isEmpty {
                    Text("Note: \(order.notes)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    OrderRowView(order: TeamOrder(name: "Sam", drink: "Coffee", size: "Medium", milk: "Regular", sugar: "Double Double", notes: "Extra sleeve", isFavourite: false))
}
