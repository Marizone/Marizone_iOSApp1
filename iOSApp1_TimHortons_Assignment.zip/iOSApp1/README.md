# iOSApp1 - Tim Hortons Coffee Run App

This project was created for MWD3A iOS Development Assignment 1.

## App Idea

The app helps a team record Tim Hortons orders for a daily coffee run. Instead of writing every order on paper, the app stores each person's drink order so the coffee runner can check the list.

## Main Features

- Add a team member's order
- Choose drink, size, milk/cream, and sugar
- Add optional notes
- View all orders in a list
- Delete orders by swiping left
- Save orders locally using `AppStorage`
- Use a simple 10-minute coffee run timer

## How this connects to the HIITFit tutorial

The assignment asks for features similar to the HIITFit tutorial. This project uses the same beginner SwiftUI ideas:

- SwiftUI views
- NavigationStack
- List and rows
- Forms and Pickers
- State variables
- Sheets
- Timer
- Local saved data
- Comments in the code

## How to Open in Xcode

Because this submission contains the Swift files, the easiest way to use it is:

1. Open Xcode.
2. Create a new iOS App project.
3. Name it `iOSApp1`.
4. Choose SwiftUI for the interface.
5. Copy these Swift files into the project:
   - `iOSApp1App.swift`
   - `ContentView.swift`
   - `Models/TeamOrder.swift`
   - `Views/OrderRowView.swift`
   - `Views/CoffeeTimerView.swift`
6. Run the app on the iPhone simulator.

## GitHub Steps

Run these commands inside the project folder after testing the app:

```bash
git init
git add .
git commit -m "Complete Assignment 1 Tim Hortons coffee run app"
git branch -M main
git remote add origin https://github.com/username/iOSApp1.git
git push -u origin main
```

Replace `username` with your GitHub username.

## Notes

This is intentionally written as a beginner student project. It is simple, readable, and commented, but it still includes working core functionality.
